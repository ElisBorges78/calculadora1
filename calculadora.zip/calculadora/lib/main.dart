import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String numero = '0';
  double primeiroNumero = 0.0;
  String operacao = '';
  List<String> numerosEOperacoes = []; // Lista para armazenar números e operações

  void calcular(String tecla) {
    switch (tecla) {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
        setState(() {
          numero += tecla;
          numero = numero.replaceAll(',', '.');
          if (numero.contains('.')) {
            double numeroDouble = double.parse(numero);
            numero = numeroDouble.toString();
          } else {
            int numeroDouble = int.parse(numero);
            numero = numeroDouble.toString();
          }
          numero = numero.replaceAll(',', '.');
        });
        break;

      case '+':
      case 'x':
      case '-':
      case '/':
        operacao = tecla;
        numero = numero.replaceAll(',', '.');
        primeiroNumero = double.parse(numero);
        numero = numero.replaceAll('.', ',');
        numero = '0';
        // Adiciona número e operação à lista
        numerosEOperacoes.add(primeiroNumero.toString());
        numerosEOperacoes.add(operacao);
        break;

      case '=':
        if (numero.isNotEmpty) {
          numerosEOperacoes.add(numero.replaceAll(',', '.'));
        }
        double resultado = double.parse(numerosEOperacoes[0]);

        for (int i = 1; i < numerosEOperacoes.length; i += 2) {
          String operacao = numerosEOperacoes[i];
          double proximoNumero = double.parse(numerosEOperacoes[i + 1]);
          if (operacao == '+') {
            resultado += proximoNumero;
          } else if (operacao == '-') {
            resultado -= proximoNumero;
          } else if (operacao == 'x') {
            resultado *= proximoNumero;
          } else if (operacao == '/') {
            if (proximoNumero == 0) {
              print('Erro Divindo por Zero!!');
              return;
            }
            resultado /= proximoNumero;
          }
        }

        setState(() {
          numero = resultado.toString();
          // Limpa a lista para permitir novos cálculos
          numerosEOperacoes.clear();
          // Adiciona o resultado à lista para possibilitar a continuação do cálculo
          numerosEOperacoes.add(numero);
        });
        break;

      case 'AC':
        setState(() {
          numero = '0';
          // Limpa a lista
          numerosEOperacoes.clear();
        });
        break;

      case '<x':
        setState(() {
          if (numero.isNotEmpty) {
            numero = numero.substring(0, numero.length - 1);
          }
          if (numero.isEmpty) {
            numero = '0';
          }
        });
        break;

      default:
        setState(() {
          numero += tecla;
        });
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Center(
            child: Text('Calculadora'),
          ),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Column(
                  children: [
                    Text(numero, style: TextStyle(fontSize: 72)),
                    SizedBox(height: 10),
                    // Exibe a lista de números e operações
                    Text(
                      numerosEOperacoes.join(' '),
                      style: TextStyle(fontSize: 24),
                      textAlign: TextAlign.end,
                    ),
                  ],
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.orange),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('AC'),
                  child: Text('AC', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () {},
                  child: Text(' '),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () {},
                  child: Text(' '),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.red),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('<x'),
                  child: Text('DEL', style: TextStyle(fontSize: 48)),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('7'),
                  child: Text('7', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('8'),
                  child: Text('8', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('9'),
                  child: Text('9', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blueGrey),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('/'),
                  child: Text('/', style: TextStyle(fontSize: 48)),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('4'),
                  child: Text('4', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('5'),
                  child: Text('5', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('6'),
                  child: Text('6', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blueGrey),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('x'),
                  child: Text('x', style: TextStyle(fontSize: 48)),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('1'),
                  child: Text('1', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('2'),
                  child: Text('2', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('3'),
                  child: Text('3', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blueGrey),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('-'),
                  child: Text('-', style: TextStyle(fontSize: 48)),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blue),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('0'),
                  child: Text('0', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blueGrey),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular(','),
                  child: Text(',', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.green),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('='),
                  child: Text('=', style: TextStyle(fontSize: 48)),
                ),
                TextButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.blueGrey),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () => calcular('+'),
                  child: Text('+', style: TextStyle(fontSize: 48)),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}